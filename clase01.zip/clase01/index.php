<?php ini_set('display_error', 1) ?>
<?php
echo 'Hola Mundo!<br>';
echo 'Hoy es Lunes!<br>';

//http://localhost/objetos/clase01/
//  ; terminador de sentencias
//  <br>    salto de linea

//Lineas de comentarios

/*
    Bloque
    de 
    comentarios
*/

/**
 * PHPDocs
 * JavaDocs
 */

//TODO Tarea pendiente


//explicar errores

//Tipo datos primitivo
/*

    Lenguajes de tipado debil:  PHP, Javascript, Python

    Lenguajes de tipado fuerte: Java, C++, C#, Visual Basic

*/

//declaración de una variable
$a;

//asignación de valor a una variable
$a = 4;
echo $a . '<br>';
$a = 3.14;
echo $a . '<br>';
$a = true;
echo $a . '<br>';
$a = "Hola";
echo $a . '<br>';

echo phpversion() . '<br>';
//echo phpinfo().'<br>';

//paradigma de objetos
/*
    Que es una clase: una clase es una plantilla o
        molde, se detecta como un sustantivo (vida real)
        y se identifica en singular y primer letra
        en mayuscula luego en minuscula.

    Que es un atributo: describe a la clase,
        es una variable contenida dentro de la 
        clase. Las clases fijan los atributos
        y los objetos completan el estado

    Que es un método: es una acción que realiza
        la clase, se detecta como verbo,
        puede tener valores de entrada y salida.

*/

//TODO Crear Objetos

//declaración de clase
class Auto {

    //código indentado

    // atributos
    public $marca;
    public $modelo;
    public $color;
    public $velocidad;

    // métodos
    public function acelerar() {
        //$this->velocidad=$this->velocidad+10;
        $this->velocidad += 10;
    }

    public function frenar(){
        $this->velocidad -= 10; 
    }

}//end class

?>