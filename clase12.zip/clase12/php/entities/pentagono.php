<?php
/**
 * Pentagono Regular
 */
class Pentagono extends Figura{
    private $lado;

    public function __construct($lado){
        $this->lado = $lado;
    }

    public function getPerimetro():float{
        return $this->lado*5;
    }

    public function getSuperficie():float{
        return $this->getPerimetro()*$this->getApotema()/2;
    }

    public function getApotema(): float {
        return $this->lado / (2 * tan(pi() / 5));
    }

    public function getEstado(): string {
        return "Pentágono: Lado = ".$this->lado;
    }

}   
?>