<?php
//require_once "../entities/figura.php";
class Rectangulo extends Figura{
    private $base;
    private $altura;

    public function __construct($base, $altura){
        $this->base = $base;
        $this->altura = $altura;
    }

    public function getPerimetro():float{
        return ($this->base+$this->altura)*2;
    }

    public function getSuperficie():float{
        return $this->base*$this->altura;
    }

    public function __tostring(){
        return $this->base.", ".$this->altura;
    }
    public function getEstado():string{
        return $this->__tostring();
    }
}
?>