<?php
class Auto{
    private $marca;                 //atributo de objeto
    private $modelo;                //atributo de objeto
    private $color;                 //atributo de objeto
    private static $velocidad=0;    //atributo de clase

    public function __construct(string $marca, string $modelo, string $color){
        $this->marca = $marca;
        $this->modelo = $modelo;
        $this->color = $color;
    }

    public function __tostring() : string{
        return $this->marca.", ".$this->modelo.", ".$this->color;
    }

    public static function acelerar(int $kilometros){   //método de clase
        self::$velocidad+=$kilometros;
    }

    public static function frenar(int $kilometros){
        self::$velocidad-=$kilometros;
    }

    public static function getVelocidad() : int{
        return self::$velocidad;
    }

    public function __get($property){
        if(property_exists($this, $property)) {
            return $this->$property;
        }
    }

    public function __set($property, $value){
        if(property_exists($this, $property)) {
            $this->$property = $value;
        }
    }
}
?>