<?php
    require_once "../entities/auto.php";

    echo "<h1>Test Vectores</h1>";

    //vector tradicional indexado
    echo"<h2>vector tradicional indexado</h2>";
    $vector[0]=new Auto("Fiat","Idea","Gris");
    $vector[1]=new Auto("Ford","Ka","Negro");
    $vector[2]=new Auto("Renault","Clio","Rojo");
    $vector[3]=new Auto("VW","Gol","Negro");
    $vector[4]="Hola PHP";
    $vector[5]= 25;
    $vector[6]=new Auto("Fiat","1500","Verde");

    //Recorrido por indices
    for($i=0;$i<count($vector); $i++){
        echo $vector[$i]."<br>";
    }

    //Collection no indexada
    echo "<h2>Collection no indexada</h2>";
    $autos[]=new Auto("Toyota","Corolla","Blanco");             //0
    $autos[]=new Auto("Honda","City","Azul");                    //1
    $autos[]=new Auto("Ford","Fiesta","Rojo");                  //2
    $autos[]=new Auto("Hiundai","I10","Negro");                 //3

    //Agregar los autos de vector en la lista autos, asegurase de que
    //solo se agreguen objetos del tipo auto
    foreach($vector as $auto){
        //echo gettype($auto)."<br>";
        //echo get_class( $auto )."<br>";
        if(gettype($auto) == "object" && get_class($auto) == "Auto")
            $autos[]=$auto;
    }

    foreach($autos as $auto){
        echo $auto."<br>";
    }

    //Diccionarios o vectores asociativos o mapa
    echo "<h2>Diccionarios</h2>";
    $vehiculos = array(
        "Juan"      =>  new Auto("Toyota","Corolla","Blanco") ,
        "Ana"       =>  new Auto("Honda","City","Azul"),
        "Marina"    =>  new Auto("Ford","Fiesta","Rojo"),
        "Alfredo"   =>  new Auto("Hiundai","I10","Negro")
    );

    echo $vehiculos["Marina"]."<br>";

    foreach ($vehiculos as $key => $value) {
        echo $key.": ".$value."<br>";
    }


    echo "<br>-- end Test --";
?>