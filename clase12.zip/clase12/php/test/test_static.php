<?php ini_set("display_errors","1");?>
<?php
    require_once "../entities/auto.php";
    
    echo "<h1>Test Static</h1>";

    Auto::acelerar(50);
    echo Auto::getVelocidad()."<br>";


    echo "-- auto1 --<br>";
    $auto1=new Auto("Renault","Kangoo","Bordo");
    //$auto1->acelerar(25);
    Auto::acelerar(25);
    //echo $auto1.", ".$auto1->getVelocidad()."<br>";
    echo $auto1.", ".Auto::getVelocidad()."<br>";

    echo "-- auto2 --<br>";
    $auto2=new Auto("Citroen","C3","Verde");
    //$auto2->acelerar(20);
    Auto::acelerar(20);
    //echo $auto2.", ".$auto2->getVelocidad()."<br>";
    //echo $auto1.", ".$auto1->getVelocidad()."<br>";
    echo $auto2.", ".Auto::getVelocidad()."<br>";
    echo $auto1.", ".Auto::getVelocidad()."<br>";



?>