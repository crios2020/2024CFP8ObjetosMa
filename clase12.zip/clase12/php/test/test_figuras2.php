<?php ini_set("display_errors","1");?>
<?php
require_once "../entities/figura.php";
require_once "../entities/rectangulo.php";
require_once "../entities/triangulo.php";
require_once "../entities/circulo.php";
require_once "../entities/pentagono.php";

//http://localhost/objetos/clase11/php/test/test_figuras2.php
echo "<h1>Test Figuras</h1>";

echo "-- Test Rectangulo --<br>";
echo "-- rectangulo1 --<br>";
$rectangulo1=new Rectangulo(25,50);
echo "Estado: ".$rectangulo1->getEstado()."<br>";
echo "Perimetro: ".$rectangulo1->getPerimetro()."<br>";
echo "Superficie: ".$rectangulo1->getSuperficie()."<br>";
echo "-- end test Rectangulo --<br><br>";

echo "-- Test Triangulo --<br>";
echo "-- triangulo1 --<br>";
$triangulo1=new Triangulo(25,50);
echo "Estado: ".$triangulo1->getEstado()."<br>";
echo "Perimetro: ".number_format($triangulo1->getPerimetro(),2)."<br>";
echo "Superficie: ".number_format($triangulo1->getSuperficie(),2)."<br>";
echo "-- end test Triangulo --<br><br>";

echo "-- Test Circulo --<br>";
echo "-- circulo1 --<br>";
$circulo1=new Circulo(65);
echo "Estado: ".$circulo1->getEstado()."<br>";
echo "Perimetro: ".number_format($circulo1->getPerimetro(),2)."<br>";
echo "Superficie: ".number_format($circulo1->getSuperficie(),2)."<br>";
echo "-- end test Circulo --<br><br>";

echo "-- Test Pentagono --<br>";
echo "-- pentagono1 --<br>";
$pentagono1=new pentagono(65);
echo "Estado: ".$pentagono1->getEstado()."<br>";
echo "Perimetro: ".number_format($pentagono1->getPerimetro(),2)."<br>";
echo "Superficie: ".number_format($pentagono1->getSuperficie(),2)."<br>";
echo "-- end test Pentagono --<br><br>";

?>