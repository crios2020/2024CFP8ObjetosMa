<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- http://localhost/objetos/clase21/calculadora.php --> 
    <h1>Calculadora</h1>
    <form>
        <table>
            <tr>
                <td><label class="etiqueta">Número 1: </label></td>
                <td>
                    <input type="number" name="nro1" class="input texto" value="0" step="0.0001">
                </td>
            </tr>
            <tr>
                <td><label class="etiqueta">Número 1: </label></td>
                <td>
                    <input type="number" name="nro2" class="input texto" value="0" step="0.0001">
                </td>
            </tr>
            <tr>
                <td><label class="etiqueta">Operación: </label></td>
                <td>
                    <select class="input select" name="operacion" >
                        <option value="suma" >Sumar</option>
                        <option value="resta">Restar</option>
                        <option value="div">Dividir</option>
                        <option value="multi">Multiplicar</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td><input type="reset"  class="boton botonBorrar" value="Borrar"></td>
                <td><input type="submit" class="boton botonEnviar" value="Calcular"></td>
            </tr>
            <tr>
                <td><label class="etiqueta">Resultado: </label></td>
                <td>
                    <div class="input text">
                        <?php include_once "php/calculadora.php"; ?>
                    </div>
                </td>
            </tr>
        </table>
    </form>
</body>
</html>