<?php
class Direccion{
    private $calle;
    private $nro;
    private $piso;
    private $depto;
    private $ciudad;

    /**
     * @param string $ciudad Si se omite el párametro pone por defecto
     *      Ciudad Autónoma de Buenos Aires
     */
    public function __construct(
        string $calle, 
        int $nro, 
        string $piso, 
        string $depto, 
        string $ciudad="CABA") {

        $this->calle = $calle;
        $this->nro = $nro;
        $this->piso = $piso;
        $this->depto = $depto;
        $this->ciudad = $ciudad;
    }

    public function __tostring(){
        return  $this->calle.", ".$this->nro.", ".$this->piso.", ".
                $this->depto.", ".$this->ciudad;
    }

     /**
     * Método mágico __get()
     */
    public function __get($property){
        if(property_exists($this,$property)){
            return $this->$property;
        }

    }

    /**
     * Método mágico __set()
     */
    public function __set($property, $value){
        //insert into control_auditoria (user, ip, fecha, hora, accion) values (?,?,?,?,?);
        if(property_exists($this,$property)){
            $this->$property = $value;
        }
    }
    
}
?>