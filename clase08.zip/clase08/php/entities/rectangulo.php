<?php
class Rectangulo {
    private $lado1;
    private $lado2;

    public function __construct(float $lado1, float $lado2) {
        $this->lado1 = $lado1;
        $this->lado2 = $lado2;
    }

    public function getPerimetro() :float {
        return ($this->lado1 + $this->lado2) * 2;
    }

    public function getSuperficie() :float{
        return $this->lado1 * $this->lado2;
    }

    public function __tostring() :string {
        return "lado1: ".$this->lado1 .", lado2: ". $this->lado2;
    }
}
?>