<?php
require_once "../entities/persona.php";
class Cliente extends Persona{

    public function __construct(
        string $nombre,
        int $edad,
        Direccion $direccion,
        public int $nroCliente,
        public Cuenta $cuenta
    ) {
        parent::__construct($nombre, $edad, $direccion);
    }

    public function saludar(): string{
        return "Hola soy un cliente";
    }

    public function __tostring(): string{
        return parent::__tostring().", ".$this->nroCliente.", ".
                    $this->cuenta;
    }

}
?>