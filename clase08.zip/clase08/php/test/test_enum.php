<?php ini_set("display_errors","1");?>
<?php 
    require_once "../enums/estado_civil.php";
    echo "-- Test Enum -- <br>";
    $estado = EstadoCivil::CASADO;
    echo $estado->name."<br>";
    echo gettype($estado)."<br>";       //object
    //echo gettype("hola")."<br>";      //string
    //echo gettype(2)."<br>";           //integer
    //echo gettype(true)."<br>";        //boolean
    //echo gettype(3.14)."<br>";        //double
    echo "-- End Test --<br>";
?>