<?php
// Versión de IA
//http://localhost/objetos/clase08/php/test/test_diagrama_figuras_ia.php
class Rectangulo {
    private $lado1;
    private $lado2;

    public function __construct($lado1, $lado2) {
        $this->lado1 = $lado1;
        $this->lado2 = $lado2;
    }

    public function getPerimetro() :float {
        return 2 * ($this->lado1 + $this->lado2);
    }

    public function getSuperficie() {
        return $this->lado1 * $this->lado2;
    }
}

// Objeto de prueba
$rectangulo = new Rectangulo(4, 5);
echo "Rectángulo - Perímetro: " . $rectangulo->getPerimetro() . ", Superficie: " . $rectangulo->getSuperficie() . "\n";

class Triangulo {

    
    public function __construct(
        private float $base,
        private float $altura
    ) {}

    public function getPerimetro(): string {
        $hipotenusa = hypot($this->base, $this->altura);
        $perimetro = $this->base + $this->altura + $hipotenusa;
        return number_format($perimetro, 2); // Redondea a dos decimales y convierte a string
    }

    public function getSuperficie(): float {
        return 0.5 * $this->base * $this->altura;
    }
}

// Objeto de prueba
$triangulo = new Triangulo(4, 3);
echo "Triángulo - Perímetro: " . $triangulo->getPerimetro() . ", Superficie: " . $triangulo->getSuperficie() . "\n";
class Circulo {
    private $radio;

    public function __construct($radio) {
        $this->radio = $radio;
    }

    public function getPerimetro() {
        return 2 * pi() * $this->radio;
    }

    public function getSuperficie() {
        return pi() * pow($this->radio, 2);
    }
}

// Objeto de prueba
$circulo = new Circulo(20);
echo "Círculo - Perímetro: " . $circulo->getPerimetro() . ", Superficie: " . $circulo->getSuperficie() . "\n";

?>