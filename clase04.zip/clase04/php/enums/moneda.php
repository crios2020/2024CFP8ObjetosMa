<?php
enum Moneda{
    case ARGS;
    case USD;
    case REALES;
}
?>