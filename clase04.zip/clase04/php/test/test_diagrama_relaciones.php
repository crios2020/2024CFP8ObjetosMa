<?php ini_set("display_errors","1"); ?>
<?php
    require_once "../entities/cuenta.php";
    echo "-- Test Díagrama Relaciones --<br><br>";
    echo "-- Test Clase Cuenta --<br>";
    echo "-- cuenta1 --";
    $cuenta1=new Cuenta(1,Moneda::ARGS);
    $cuenta1->depositar(500000);
    $cuenta1->depositar(300000);
    $cuenta1->debitar(50000);
    echo $cuenta1."<br>";
    echo "-- End Test Cuenta --<br>"

    
?>