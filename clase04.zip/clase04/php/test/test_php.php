<?php ini_set("display_errors","1");?>
<?php 
    //http://localhost/objetos/clase04/php/test/test_php.php
    echo "Versión PHP: ".phpversion()."<br>";
?>