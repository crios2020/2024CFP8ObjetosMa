<?php
require_once "../entities/Cuenta.php";
class ClientePersona{
    private $nro;
    private $nombre;
    private $edad;
    private $cuenta;

    /*
        Constructor que indica que un cliente no siempre tiene una
        cuenta. Después se agrega con un método.
    */
    //public function __construct(
    //                                int $nro, 
    //                                string $nombre, 
    //                                int $edad) {
    //    $this->nro = $nro;
    //    $this->nombre = $nombre;
    //    $this->edad = $edad;
    //}

    /*
        El cliente siempre tiene una cuenta.
        Una cuenta puede pertenecer a más de un cliente.
    */
    //TODO Ensayar el caso de dos clientes con una misma cuenta!
    // public function __construct(
    //                                int $nro, 
    //                                string $nombre, 
    //                                int $edad,
    //                                Cuenta $cuenta) {
    //    $this->nro = $nro;
    //    $this->nombre = $nombre;
    //    $this->edad = $edad;
    //    $this->cuenta = $cuenta; 

    /*
        Un cliente siempre tiene una sola cuenta.
        La cuenta se crea dentro del cliente y es propia.
     */
    public function __construct(
                                   int $nro, 
                                   string $nombre, 
                                   int $edad,
                                   int $nro_cuenta,
                                   Moneda $moneda
                                ) {
       $this->nro = $nro;
       $this->nombre = $nombre;
       $this->edad = $edad;
       $this->cuenta = new Cuenta($nro_cuenta, $moneda);
    }
    
}
?>