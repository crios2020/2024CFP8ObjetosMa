function confirmarBorrar(){
    return confirm("Desea borrar un curso?")
}