<?php
interface I_File{
    /*
    Interfaces:
        -Todos sus miembros son publicos.
        -No tiene atributos de objetos.
        -No tiene constructores.
        -Puede tener atributos de clase (static).
        -Puede tener atributos constantes.
        -Los métodos son abstractos.

        -Una clase puede implementar muchas interfaces
        -Una interface se dice que es un contrato de métodos.
        -La PHPDocs es heredada.
        -Una interface puede ser implementada en muchas clases.
    */

    /**
     * método que devuelve el texto del archivo
     * @return string   texto del archivo
     */
    function get_text(): string;

    /**
     * método que escribe el texto del archivo
     * @param string $text  texto a escribir
     * @return void sin devolución
     */
    function set_text(string $text): void;

    //métodos default PHP 8.3
    //Un método default tiene cuerpo(código)
    //Como una clase puede implementar varias interfaces y estas interfaces 
    //pueden tener métodos con comportamiento(código), se genera una forma
    //de herencia multiple.
    // function info() : string{
    //     return "Interface I_File";
    // }

}

//TODO diferencias entre clases abstractas e interfaces
//TODO static
?>