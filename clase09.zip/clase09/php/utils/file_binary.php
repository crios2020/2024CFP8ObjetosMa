<?php
require_once "../interfaces/i_file.php";
class I_File_Binary implements I_File{
    public function get_text(): string{
        return "Texto de Archivo Binario";
    }
    public function set_text(string $text): void{
        echo "Escribiendo Archivo Binario!";
    }

    //no seria necesario sobre escribir a partir de PHP 8.3 por que es default
    public function info() : string{
        return "Interface I_File";
    }
}
?>