<?php

/**
 * Asumimos que es un triángulo rectangulo
 */
class Triangulo {
    private $base;
    private $altura;

    public function __construct(float $base, float $altura) {
        $this->base = $base;
        $this->altura = $altura;
    }

    public function getPerimetro() : float {
        //$hipotenusa = sqrt(($this->base ** 2) + ($this->altura ** 2));
        //return $this->base + $this->altura + $hipotenusa;
        $hipotenusa = hypot($this->base, $this->altura);
        return $this->base + $this->altura + $hipotenusa;
    }

    public function getSuperficie() : float{
        return 0.5 * $this->base * $this->altura;
    }

    public function __tostring() :string {
        return "base: ".$this->base .", altura: ". $this->altura;
    }

}

?>