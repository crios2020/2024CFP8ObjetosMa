<?php
require_once "../entities/direccion.php";
abstract class Persona{

    /*
        Clase concreta: Se puede instanciar, se pueden crear objetos de la clase
                        se pueden crear clases hijas y objetos de clases hijas.


        Clase abstracta: No se puede instanciar, no se pueden crear objetos.
                        Si se pueden crear clases hijas y objetos de clases hijas.

        Clase sellada(final):   Se pueden crear objetos de la clases,
                        no se pueden crear clases derivadas (clases hijas)

        Métodos abstractos: Son métodos sin cuerpo (sin códigos), solo puede
                        estar dentro de una clase abstracta. las clases 
                        hijas deben implementar (deben escribir el código).
        Los métodos abstractos dicen que hay que hacer, pero no el como se hace.
        Las implementaciones (clases hijas) dicen el como se hace

        Nota: una clase abstracta no necesariamente incorpora métodos abstractos

    */

    private $nombre;
    private $edad;
    private $direccion;

    public function __construct(String $nombre, int $edad, Direccion $direccion){
        $this->nombre = $nombre;
        $this->edad = $edad;
        $this->direccion = $direccion;
    }

    // public function saludar(){
    //     echo "Hola soy una persona!<br>";
    // }
 
    public abstract function saludar() :string;

    public function __tostring() : string{
        return $this->nombre.", ".$this->edad.", ".$this->direccion;
    }


    /**
     * Método mágico __get()
     */
    public function __get($property){
        if(property_exists($this,$property)){
            return $this->$property;
        }

    }

    /**
     * Método mágico __set()
     */
    public function __set($property, $value){
        //insert into control_auditoria (user, ip, fecha, hora, accion) values (?,?,?,?,?);
        if(property_exists($this,$property)){
            $this->$property = $value;
        }
    }
}
?>