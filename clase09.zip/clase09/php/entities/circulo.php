<?php
class Circulo {
    private $radio;

    public function __construct(float $radio) {
        $this->radio = $radio;
    }

    public function getPerimetro() : float{
        return pi() * $this->radio * 2;
    }

    public function getSuperficie() : float{
        return pi() * pow($this->radio, 2);
        //return pi() * $this->radio * $this->radio;
    }

    public function __tostring() :string {
        return "radio: ".$this->radio;
    }

}
?>