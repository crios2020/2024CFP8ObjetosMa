<?php
require_once "../entities/cuenta.php";
class ClientePersona{
    private $nro;
    private $nombre;
    private $edad;
    private $cuenta;

    /*
        Constructor que indica que un cliente no siempre tiene una
        cuenta. Después se agrega con un método.
    */
    //public function __construct(
    //                                int $nro, 
    //                                string $nombre, 
    //                                int $edad) {
    //    $this->nro = $nro;
    //    $this->nombre = $nombre;
    //    $this->edad = $edad;
    //}

    /*
        El cliente siempre tiene una cuenta.
        Una cuenta puede pertenecer a más de un cliente.
    */
    //TODO Ensayar el caso de dos clientes con una misma cuenta!
    public function __construct(
                                   int $nro, 
                                   string $nombre, 
                                   int $edad,
                                   Cuenta $cuenta) {
       $this->nro = $nro;
       $this->nombre = $nombre;
       $this->edad = $edad;
       $this->cuenta = $cuenta; 
    }
    
    /*
        Un cliente siempre tiene una sola cuenta.
        La cuenta se crea dentro del cliente y es propia.
     */
    // public function __construct(
    //                                int $nro, 
    //                                string $nombre, 
    //                                int $edad,
    //                                int $nro_cuenta,
    //                                Moneda $moneda
    //                             ) {
    //    $this->nro = $nro;
    //    $this->nombre = $nombre;
    //    $this->edad = $edad;
    //    $this->cuenta = new Cuenta($nro_cuenta, $moneda);
    // }

    public function comprar() :string{
        //método Dummy
        return "Comprando un producto!";
    }

    public function __toString() :string{
        return  $this->nro.", ".$this->nombre.", ".
                $this->edad.", ".$this->cuenta;
    }

        /**
     * Método mágico __get()
     */
    public function __get($property){
        if(property_exists($this,$property)){
            return $this->$property;
        }

    }

    /**
     * Método mágico __set()
     */
    public function __set($property, $value){
        //insert into control_auditoria (user, ip, fecha, hora, accion) values (?,?,?,?,?);
        if(property_exists($this,$property)){
            $this->$property = $value;
        }
    }
    
}
?>