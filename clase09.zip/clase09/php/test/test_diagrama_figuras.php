<?php ini_set("display_errors","1"); ?>
<?php
//http://localhost/objetos/clase08/php/test/test_diagrama_figuras.php
require_once "../entities/rectangulo.php";
require_once "../entities/triangulo.php";
require_once "../entities/circulo.php";

echo "<h1>Test Figuras</h1>";
echo "Test Rectangulo<br>";
echo "-- rectangulo1 --<br>";
$rectangulo1=new Rectangulo(20,30);
echo $rectangulo1."<br>";
echo "Perímetro: ".$rectangulo1->getPerimetro()."<br>";
echo "Superficie: ".$rectangulo1->getSuperficie()."<br>";
echo "End Test Rectángulo<br><br>";

echo "Test Triángulo<br>";
echo "-- triangulo1 --<br>";
$triangulo1=new Triangulo(20,30);
echo $triangulo1."<br>";
echo "Perímetro: ".number_format($triangulo1->getPerimetro(), 2)."<br>";
echo "Superficie: ".$triangulo1->getSuperficie()."<br>";
echo "End Test Triángulo<br><br>";

echo "Test Círculo<br>";
echo "-- círculo1 --<br>";
$circulo1=new Circulo(30);
echo $circulo1."<br>";
echo "Perímetro: ".number_format($circulo1->getPerimetro(),2)."<br>";
echo "Superficie: ".number_format($circulo1->getSuperficie(),2)."<br>";
echo "End Test Círculo<br><br>";
?>