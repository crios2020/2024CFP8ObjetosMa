<?php ini_set("display_errors","1"); ?>
<?php 

//http://localhost/objetos/clase09/php/test/test_diagrama_herencia.php

require_once "../entities/cuenta.php";
require_once "../entities/direccion.php";
require_once "../entities/persona.php";
require_once "../entities/vendedor.php";
require_once "../entities/cliente.php";

echo "-- Test Díagrama Herencia --<br><br>";
echo "-- Test Clase Cuenta --<br>";
echo "-- cuenta1 --<br>";
$cuenta1=new Cuenta(1,Moneda::ARGS);
$cuenta1->depositar(500000);
$cuenta1->depositar(300000);
$cuenta1->debitar(50000);
echo $cuenta1."<br>";
echo "-- End Test Cuenta --<br><br>";

echo "-- Test Clase Direccion --<br>";
echo "-- direccion1 --<br>";
$direccion1=new Direccion("Medrano", 162, "1","a");
echo $direccion1."<br>";

echo "-- direccion2 --<br>";
$direccion2=new Direccion("Belgrano", 350,"","","Morón");
echo $direccion2."<br>";

echo "-- End Test Direccion --<br><br>";



echo "-- Test Clase Persona --<br>";

/*
echo "-- persona1 --<br>";
$persona1=new Persona("Juan Perez",34,$direccion1);
echo $persona1."<br>";
echo $persona1->saludar()."<br>";

echo "-- persona2 --<br>";
$persona2=new Persona("Ana Mendez",35,$persona1->__get("direccion"));
echo $persona2."<br>";
echo $persona2->saludar()."<br>";

echo "-- End Test Persona --<br><br>";
*/

echo "-- Test Clase Vendedor --<br>";
echo "-- vendedor1 --<br>";
$vendedor1=new Vendedor(
                            "Lorena Breaco", 
                            34,
                            new Direccion("Lima",222,"3","a"),
                            1,
                            890000
                        );
echo $vendedor1."<br>";
echo $vendedor1->saludar()."<br>";


echo "-- End Test Vendedor --<br><br>";

echo "-- Test Clase Cliente --<br>";
echo "-- cliente1 --<br>";
$cliente1=new Cliente("Marina",34,$direccion1,1, $cuenta1);
echo $cliente1."<br>";

//se mudo el cliente1
$cliente1->__set("direccion",new Direccion("Rivadavia",34,"1","1"));
$cliente1->__get("cuenta")->depositar(32000);
// $cliente1->cuenta->depositar(2300);
echo $cliente1."<br>";

echo "-- End Test Cliente --<br><br>";

//TODO Poliformismo
//TODO Interfaces
?>
