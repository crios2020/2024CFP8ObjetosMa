<?php ini_set("display_errors","1"); ?>
<?php
    require_once "../entities/persona.php";
    require_once "../entities/cliente.php";
    require_once "../entities/vendedor.php";
    require_once "../entities/cuenta.php";
    require_once "../entities/direccion.php";
    
    //Clase 09      Polimorfismo - Poliformismo
    //http://localhost/objetos/clase09/php/test/test_polimorfismo.php

    // echo"-- persona1 --";
    // $persona1=new Persona("Juan",23,new Direccion("viel",22,"1","a"));
    // echo $persona1."<br>";

    echo"-- personaA --";
    $personaA=new Vendedor(
                            "Ana",
                            23,
                            new Direccion("Lima",22,"",""),
                            1,
                            666666
                        );
    echo $personaA."<br>";
    echo $personaA->saludar() ."<br>";

    echo"-- personaB --";
    $personaB=new Cliente(
                            "Juan",
                            34,
                            new Direccion("lima",33,"",""),
                            1,
                            new Cuenta(1,Moneda::ARGS)
                        );
    echo $personaB."<br>";
    echo $personaB->saludar() ."<br>";
    
    /*
        Polimorfismo: es cuando una clase presenta distinto comportamiento.

        Polimorfismo sin redefinición de métodos: se utilizan técnicas de 
                        sobrecarga de métodos o párametros por omisión.
                        Hay varios autores que no consideran esta forma como 
                        polimorfismo.
        
        Polimorfismo con redefinición de métodos:   se sobreescriben métodos de
                        la clase padre por que deben funcional levemente distinos

                        EJ: CajaDeAhorro(padre)     CuentaCorriente(hija)
                            Auto(padre)             AutoDeCarrera(hija)

                        Al debitar dinero, se extrae de la misma forma en una
                        Caja de ahorro que de una Cuenta Corriente?

                        Aceleran de la misma forma un auto de calle que uno de
                        carreras?

    */

    echo    "personaA: tipo: ".gettype($personaA).
            ", clase: ".get_class($personaA).
            ", clase padre: ".get_parent_class($personaA)."<br>";
            
    echo    "personaB: tipo: ".gettype($personaB).
            ", clase: ".get_class($personaB).
            ", clase padre: ".get_parent_class($personaB)."<br>";
    

?>