<?php ini_set("display_errors","1"); ?>
<?php
require_once "../utils/file_binary.php";
require_once "../utils/file_text.php";
//http://localhost/objetos/clase09/php/test/test_interfaces.php
echo "<h1>Test Polimorfismo</h1>";

//declaración
$i_file=new File_Text();

//inicialización
//$i_file=new File_Text();
//$i_file=new I_File_Binary();

//pedir para metros por url

//sin párametros de entrada
//http://localhost/objetos/clase09/php/test/test_interfaces.php

//pidiendo implementación texto
//http://localhost/objetos/clase09/php/test/test_interfaces.php?modo=texto

//pidiendo implementación binaria
//http://localhost/objetos/clase09/php/test/test_interfaces.php?modo=binario

//echo $_REQUEST['modo']."<br>";
if(isset($_REQUEST['modo']) && $_REQUEST['modo']=="texto") 
    $i_file=new File_Text();

if(isset($_REQUEST['modo']) && $_REQUEST['modo']=="binario") 
    $i_file=new I_File_Binary();

//Programción Reflectica
//$i_file? new (String $_REQUEST['modo']);


//App o uso
$i_file->set_text("Hola...");
echo "<br>".$i_file->get_text()."<br>";
echo "<br>".$i_file->info()."<br>";

//TODO publicar el primer TP entregable
//TODO Static



echo "<h3>End Test</h3>"
?>