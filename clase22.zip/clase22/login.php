<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>

    <div class="container-lg bg-info-subtle">
        <h1 class="text-success text-center p-2 m-2 bg-info">Login</h1>

        <form class="bg-secondary-subtle m-3 p-3" method="POST">

            <!-- User -->
            <div class="mb-3 row">
                <label for="user" class="col-sm-3 col-form-label text-primary">User</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control text-primary" id="user" minlength="3" maxlength="20"
                        name="user" required placeholder="Ingrese su nombre de usuario">
                </div>

            </div>

            <!-- Password -->
            <div class="mb-3 row">
                <label for="pass" class="col-sm-3 col-form-label text-primary">Password</label>
                <div class="col-sm-9">
                    <input type="password" class="form-control text-primary" id="pass" minlength="3" maxlength="20"
                        name="pass" required placeholder="Ingrese su clave">
                </div>
            </div>

            <!-- Botones -->
            <div class="mb-3 row">
                <button type="submit" class="btn btn-success col-sm-3 m-2">Login</button>
                <button type="reset" class="btn btn-danger col-sm-3 m-2">Borrar</button>
            </div>

            <!-- Información -->
            <div class="mb-3 row">
                <label for="info" class="col-sm-3 col-form-label text-primary">Información</label>
                <div class="col-sm-9" >
                    <div class="form-control text-primary" id="info">
                        <?php include 'php/login.php'; ?>
                    </div>    
                </div>
            </div>

        </form>

        <!--
    <h1>Login</h1>
    <form>
        <table>
            <tr>
                <td>User: </td>
                <td><input type="text" required minlength="3" maxlength="20"></td>
            </tr>
            <tr>
                <td>Password: </td>
                <td><input type="password" required minlength="3" maxlength="20"></td>
            </tr>
            <tr>
                <td><input type="submit" value="Login"></td>
                <td><input type="reset"  value="Borrar"></td>
            </tr>
        </table>
    </form>
    -->

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
            crossorigin="anonymous"></script>
</body>

</html>