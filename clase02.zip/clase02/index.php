<?php ini_set('display_error', 1) ?>
<?php
    echo "Clase 2<br>";

    //paradigma de objetos
    /*
        Que es una clase: una clase es una plantilla o
            molde, se detecta como un sustantivo (vida real)
            y se identifica en singular y primer letra
            en mayuscula luego en minuscula.

        Que es un atributo: describe a la clase,
            es una variable contenida dentro de la 
            clase. Las clases fijan los atributos
            y los objetos completan el estado

        Que es un método: es una acción que realiza
            la clase, se detecta como verbo,
            puede tener valores de entrada y salida.

        Que es un objetos:  es una situación en particular de la 
            clase, cada objeto tiene un estado propio(valor de 
            atributos). La clase define los atributos y los objetos
            completan el estado

    */

    //Declaración de clase
    class Auto{
        //Declaración de atributos
        public $marca;
        public $modelo;
        public $color;
        public $velocidad;
        //métodos
        //párametros de entrada
        /**
         * Método para acelerar el coche
         * @return void
         */
        public function acelerar($kilometros=10){
            $this->velocidad +=$kilometros;
            if($this->velocidad >100) 
                $this->velocidad = 100;        
        }
        public function frenar(){
            $this->velocidad -=10;
        }
        
        public function imprimirVelocidad(){
            echo $this->velocidad."<br>";
        }
        //Método con valor de retorno
        public function getVelocidad(){
            return $this->velocidad;
        }

        public function getEstado(){
            return $this->marca.", ".$this->modelo.", ".
                    $this->color.", ".$this->velocidad;
        }

        public function __toString(){
            return $this->marca.", ".$this->modelo.", ".
                    $this->color.", ".$this->velocidad;
        }
    }//end class

    //Objetos
    echo "-- auto1 --<br>";
    $auto1 = new Auto(); // new Auto() constructor de la clase
    
    //poner estado al objeto
    $auto1->marca="Ford";
    $auto1->modelo="Ka";
    $auto1->color="Negro";
    $auto1->acelerar();              // 10
    $auto1->acelerar();              // 20
    $auto1->acelerar();              // 30
    $auto1->frenar();                // 20
    $auto1->acelerar(23);            // 43
    $auto1->imprimirVelocidad();  
    echo "<h3 style='color: red;'>"
                .$auto1->getVelocidad()."</h3>";
  
    //$auto->velocidad="muy rápido";
    //imprimimos el estado del objeto
    // echo $auto1->marca.", "
    //             .$auto1->modelo.", "
    //             .$auto1->color.", "
    //             .$auto1->velocidad."<br>";
    //echo $auto1->getEstado()."<br>";
    echo $auto1."<br>";

    echo "-- auto2 --<br>";
    $auto2 = new Auto();
    $auto2->marca= "Fiat";
    $auto2->modelo= "Idea";
    $auto2->color= "Gris";

    for($a=0; $a<=60; $a++){
        $auto2->acelerar();
    }

    // echo $auto2->marca.", "
    //             .$auto2->modelo.", "
    //             .$auto2->color.", "
    //             .$auto2->velocidad."<br>";
    //echo $auto2->getEstado()."<br>";
    echo $auto2."<br>";

    // Operadores incrementales
    echo "-- Operadores incrementales --<br>";
    $nro1=5;
    echo $nro1."<br>";          //5
    //sumar 1 a la variable     ++
    $nro1++;                    //$nro1=$nro1+1;
    echo $nro1."<br>";          //6
    //restar 1 a la variable    --
    $nro1--;                    //$nro1=nro1-1;
    echo $nro1."<br>";          //5
    //sumar 8 a la variable     +=
    $nro1+=8;                   //$nro1=$nro1+8;
    echo $nro1."<br>";  
    //restar 8 a la variable   -=
    $nro1-=8;                   //$nro1=$nro1-8;
    echo $nro1."<br>";          //5
    //multiplicar *3 la variable    *=
    $nro1*=3;                   //$nro1=$nro1*3;
    echo $nro1."<br>";          //15
    //dividir /3 la variable        /=
    $nro1/=3;                   //$nro1=$nro1/3;
    echo $nro1."<br>";          //5 

    //Precedencia y procedencia de operadores unarios
    // -- ++
    echo $nro1++."<br>";        // imprime 5
    echo $nro1."<br>";          // imprime 6
    echo --$nro1;               // imprime 5


    //TODO Métodos mágicos