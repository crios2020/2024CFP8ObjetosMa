<?php ini_set('display_errors',1) ?>
<?php
    require_once '../entities/empleado.php';
    //http://localhost/objetos/clase03/php/test/test_empleado.php
    echo "-- empleado1 --<br>";
    $empleado1 = new Empleado(
                                    1,
                                    "Jose",
                                    "Romero",
                                    EstadoCivil::SOLTERO,
                                    890000
        );
    echo $empleado1."<br>";
    echo $empleado1->saludar() ."<br>";

    //El empleado 1 se caso
    //Aumentar el sueldo basico del empleado1 en un 20%
    $empleado1->__set("estado_civil",EstadoCivil::CASADO);
    //$sueldo=$empleado1->__get("sueldo_basico");
    //$sueldo=$sueldo*=1.20;
    //$empleado1->__set("sueldo_basico",$sueldo);

    $empleado1->__set(
                    "sueldo_basico",
                    $empleado1->__get("sueldo_basico")*1.2
                );
    echo $empleado1."<br>";

    echo phpversion();
?>