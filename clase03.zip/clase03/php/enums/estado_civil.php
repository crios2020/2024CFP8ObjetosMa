<?php
enum EstadoCivil{
    case SOLTERO;
    case CASADO;
    case VIUDO;
    case DIVORCIADO;
}
?>