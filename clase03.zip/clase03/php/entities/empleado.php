<?php
require_once '../enums/estado_civil.php';
//Encapsulamiento de clase, es el ocultamiento del estado de la clase

class Empleado{
    private $id;
    private $nombre;
    private $apellido;
    private $estado_civil;
    private $sueldo_basico;

    /*
        Métodos constructores: son métodos que se ejecutan 
            automaticamente al crear un objeto, e inicializa 
            el objeto. Siémpre hay un constructor. Cuando no
            se declara el constructor, el lenguaje agrega uno
            vacio en tiempo de compilación.
    */
    public function __construct(
            int $id, 
            string $nombre, 
            string $apellido, 
            EstadoCivil $estado_civil, 
            float $sueldo_basico){
        $this->id=$id;
        $this->nombre=$nombre;
        $this->apellido=$apellido;
        $this->estado_civil=$estado_civil;
        $this->sueldo_basico=$sueldo_basico;
    }

    public function saludar(): string{   
        return "Hola soy un empleado";
    }

    public function __toString(){
        return  $this->id.", ".$this->nombre.", ".
                $this->apellido.", ".$this->estado_civil->name.", ".
                $this->sueldo_basico;
    }

    /**
     * Método mágico __get()
     */
    public function __get($property){
        if(property_exists($this,$property)){
            return $this->$property;
        }

    }

    /**
     * Método mágico __set()
     */
    public function __set($property, $value){
        if(property_exists($this,$property)){
            $this->$property = $value;
        }
    }

}
?>