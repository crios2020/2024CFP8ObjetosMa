<?php
abstract class Figura{
    public abstract function getPerimetro():float;
    public abstract function getSuperficie():float;
    public abstract function getEstado():string;
}
?>