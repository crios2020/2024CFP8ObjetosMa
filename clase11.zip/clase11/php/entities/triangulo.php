<?php
//require_once "../entities/figura.php";

/**
 * Triangulo Rectángulo
 */
class Triangulo extends Figura {
    private float $base;
    private float $altura;

    public function __construct(float $base, float $altura) {
        $this->base = $base;
        $this->altura = $altura;
    }

    public function getPerimetro(): float {
        return $this->base + $this->altura + hypot($this->base, $this->altura);
    }

    public function getSuperficie(): float {
        return $this->base * $this->altura / 2;
    }

    public function getEstado(): string {
        return "Triángulo: Base = {$this->base}, Altura = {$this->altura}";
    }
}
?>