<?php
//require_once "../entities/figura.php";
class Circulo extends Figura {
    private float $radio;

    public function __construct(float $radio) {
        $this->radio = $radio;
    }

    public function getPerimetro(): float {
        return 2 * pi() * $this->radio;
    }

    public function getSuperficie(): float {
        return pi() * ($this->radio ** 2);
    }

    public function getEstado(): string {
        return "Círculo: Radio = {$this->radio}";
    }
}
?>