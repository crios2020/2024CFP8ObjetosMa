<?php ini_set("display_errors","1");?>
<?php
//http://localhost/objetos/clase11/php/test/test_figuras2_IA.php

abstract class Figura {
    abstract public function getPerimetro(): float;
    abstract public function getSuperficie(): float;
    abstract public function getEstado(): string;
}

class Rectangulo extends Figura {
    private float $base;
    private float $altura;

    public function __construct(float $base, float $altura) {
        $this->base = $base;
        $this->altura = $altura;
    }

    public function getPerimetro(): float {
        return 2 * ($this->base + $this->altura);
    }

    public function getSuperficie(): float {
        return $this->base * $this->altura;
    }

    public function getEstado(): string {
        return "Rectángulo: Base = {$this->base}, Altura = {$this->altura}";
    }
}

class Triangulo extends Figura {
    private float $base;
    private float $altura;

    public function __construct(float $base, float $altura) {
        $this->base = $base;
        $this->altura = $altura;
    }

    public function getPerimetro(): float {
        return $this->base + 2 * sqrt(($this->base / 2) ** 2 + $this->altura ** 2);
    }

    public function getSuperficie(): float {
        return 0.5 * $this->base * $this->altura;
    }

    public function getEstado(): string {
        return "Triángulo: Base = {$this->base}, Altura = {$this->altura}";
    }
}

class Circulo extends Figura {
    private float $radio;

    public function __construct(float $radio) {
        $this->radio = $radio;
    }

    public function getPerimetro(): float {
        return 2 * pi() * $this->radio;
    }

    public function getSuperficie(): float {
        return pi() * ($this->radio ** 2);
    }

    public function getEstado(): string {
        return "Círculo: Radio = {$this->radio}";
    }
}

class Pentagono extends Figura {
    private float $lado;

    public function __construct(float $lado) {
        $this->lado = $lado;
    }

    public function getPerimetro(): float {
        return 5 * $this->lado;
    }

    public function getSuperficie(): float {
        //return (sqrt(5 * (5 + 2 * sqrt(5))) / 4) * ($this->lado ** 2);
        return $this->getPerimetro()*$this->getApotema()/2;
    }

    public function getApotema(): float {
        return $this->lado / (2 * tan(pi() / 5));
    }

    public function getEstado(): string {
        return "Pentágono: Lado = {$this->lado}, Apotema = " . $this->getApotema();
    }
}

// Objetos de prueba
$rectangulo = new Rectangulo(5, 10);
echo $rectangulo->getEstado() . PHP_EOL;
echo "Perímetro: " . $rectangulo->getPerimetro() . PHP_EOL;
echo "Superficie: " . $rectangulo->getSuperficie() . PHP_EOL;

$triangulo = new Triangulo(5, 10);
echo $triangulo->getEstado() . PHP_EOL;
echo "Perímetro: " . $triangulo->getPerimetro() . PHP_EOL;
echo "Superficie: " . $triangulo->getSuperficie() . PHP_EOL;

$circulo = new Circulo(7);
echo $circulo->getEstado() . PHP_EOL;
echo "Perímetro: " . $circulo->getPerimetro() . PHP_EOL;
echo "Superficie: " . $circulo->getSuperficie() . PHP_EOL;

$pentagono = new Pentagono(4);
echo $pentagono->getEstado() . PHP_EOL;
echo "Perímetro: " . $pentagono->getPerimetro() . PHP_EOL;
echo "Superficie: " . $pentagono->getSuperficie() . PHP_EOL;

?>