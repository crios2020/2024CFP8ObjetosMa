<?php ini_set("display_errors","1");?>
<?php

    //http://localhost/objetos/clase14/php/test/test_exceptions.php

    require_once "../utils/generador_exception.php";
    require_once "../entities/vuelo.php";
    require_once "../exceptions/no_hay_mas_pasajes_exceptions.php";
    //echo 10/0;
    //echo "Esta linea no se ejecuta!!!"

    //Estructura try - catch
    /*
    try{                            //obligatorio

        //colocar aquí todas las sentencias que pueden lanzar exception(error).
        //estas sentencias tienen un costo mayor de hardware.
        //Si es posible ejecutar este bloque sin errores, se ejecuta normalmente.
        //Si hay un error(Exception) se interrumpe la ejecución del bloque y
        // continua ejecutando en el bloque catch

    }catch(Throwable $e){           //obligatorio       //}catch(Exception $e){  //PHP 5

        //Este bloque solo se ejecuta en caso de exception en try.
        //Se recibe como párametro de entrada un objeto del tipo Exception.

    }finally{                       //opcional
        //Este bloque se ejecuta siempre!
        //Las variables declaradas en try o catch estan fuera de scope (alcance)
    }
        echo "El programa termina normalmente!!!!";
    */

    /*
    try{
        $a=4;
        echo 10/0;
        echo "Esta sentencia no se ejecuta!!<br>";
    }catch(Throwable $e){                       
        echo "Ocurrio un problema!<br>";
        echo $e->getMessage()."<br>";
        echo $e->__tostring()."<br>";
    } finally{
        $a=8;       //es otra variable
        echo "El programa termina normalmente!<br>";
    }
        */

    /*
    try{
        //Generador_Exception::generar();         //ArrayIndex
        //Generador_Exception::generar2(true);        //DivisionByZeroError
        Generador_Exception::generar3() ;
    }catch(Throwable $e){
        echo "".$e->getMessage()."<br>";
        echo $e->__tostring()."<br>";
    }
    echo "El programa termina normalmente!<br>";
    */ 

    //Captura personalizada de Exceptions
    /*
    try {
        //Generador_Exception::generar2(true); 
        Generador_Exception::generar3();
    }catch(DivisionByZeroError $e) {
        echo "Error División por cero<br>";
    }catch(Throwable $e){
        echo "Ocurrio un error no esperado!<br>";
    }
    */
    //manejo de reglas de negocio con Exception
    //publicar el segundo trabajo entregable
    
    echo "-- vuelo1 --<br>";
    $vuelo1=new Vuelo("AER1234",100);
    echo $vuelo1."<br>";

    echo "-- vuelo2 --<br>";
    $vuelo2=new Vuelo("LAT1111",100);
    echo $vuelo2."<br>";

    try{
        $vuelo1->vender(50);
        $vuelo2->vender(20);
        $vuelo1->vender(30);
        $vuelo2->vender(20);
        $vuelo1->vender(30);        //Lanza una expcetion
        $vuelo2->vender(10);        //Esta venta no se ejecuta
    }catch(NoHayMasPasajesException $e){
        echo $e."<br>";
    }catch(Exception $e){
        echo "Ocurrio un error no esperado!<br>";
    }

    

    echo "--------------------------------------------------------------<br>";
    echo "-- vuelo1 --<br>";
    echo $vuelo1."<br>";

    echo "-- vuelo2 --<br>";
    echo $vuelo2."<br>";
?>