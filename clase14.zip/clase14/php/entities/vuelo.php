<?php
require_once "../exceptions/no_hay_mas_pasajes_exceptions.php";
class Vuelo{
    private $nombre;
    private $cantidad_pasajes_disponible;

    public function __construct(string $nombre, int $cantidad_pasajes_disponible){
        $this->nombre=$nombre;
        $this->cantidad_pasajes_disponible=$cantidad_pasajes_disponible;
    }

    public function vender(int $cantidad_pasajes_pedidos) {
        if($cantidad_pasajes_pedidos>$this->cantidad_pasajes_disponible){
            throw new NoHayMasPasajesException(
                            $this->nombre, 
                            $this->cantidad_pasajes_disponible, 
                            $cantidad_pasajes_pedidos);
        }
        $this->cantidad_pasajes_disponible-=$cantidad_pasajes_pedidos;
    }

    public function __tostring() : string {
        return $this->nombre.", ".$this->cantidad_pasajes_disponible;
    }

    public function __get($property){
        if(property_exists($this, $property)) {
            return $this->$property;
        }
    }
    public function __set($property, $value){
        if(property_exists($this, $property)) {
            $this->$property = $value;
        }
    }
}
?>