<?php
class NoHayMasPasajesException extends Exception{
    private $nombre_vuelo;
    private $cantidad_pasajes_disponible;
    private $cantidad_pasajes_pedidos;

    public function __construct($nombre_vuelo, $cantidad_pasajes_disponible, $cantidad_pasajes_pedidos) {   
        $this->nombre_vuelo = $nombre_vuelo;
        $this->cantidad_pasajes_disponible = $cantidad_pasajes_disponible;  
        $this->cantidad_pasajes_pedidos = $cantidad_pasajes_pedidos;
    }

    public function __tostring() : string {
        return "El vuelo ".$this->nombre_vuelo.", no tiene "
                    .$this->cantidad_pasajes_pedidos.", solo tiene "
                    .$this->cantidad_pasajes_disponible." pasajes.";
    }
    
}

?>