function confirmarBorrar(){
    return confirm("Desea borrar un registro?")
}