-- Active: 1723855658210@@127.0.0.1@3306@negocio
select version();