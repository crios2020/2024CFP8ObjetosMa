<?php //ini_set("display_errors","1");?>
<?php
    require_once "../utils/generador_exception.php";
    //echo 10/0;
    //echo "Esta linea no se ejecuta!!!"

    //Estructura try - catch
    /*
    try{                            //obligatorio

        //colocar aquí todas las sentencias que pueden lanzar exception(error).
        //estas sentencias tienen un costo mayor de hardware.
        //Si es posible ejecutar este bloque sin errores, se ejecuta normalmente.
        //Si hay un error(Exception) se interrumpe la ejecución del bloque y
        // continua ejecutando en el bloque catch

    }catch(Throwable $e){           //obligatorio       //}catch(Exception $e){  //PHP 5

        //Este bloque solo se ejecuta en caso de exception en try.
        //Se recibe como párametro de entrada un objeto del tipo Exception.

    }finally{                       //opcional
        //Este bloque se ejecuta siempre!
        //Las variables declaradas en try o catch estan fuera de scope (alcance)
    }
        echo "El programa termina normalmente!!!!";
    */

    /*
    try{
        $a=4;
        echo 10/0;
        echo "Esta sentencia no se ejecuta!!<br>";
    }catch(Throwable $e){                       
        echo "Ocurrio un problema!<br>";
        echo $e->getMessage()."<br>";
        echo $e->__tostring()."<br>";
    } finally{
        $a=8;       //es otra variable
        echo "El programa termina normalmente!<br>";
    }
        */

    /*
    try{
        //Generador_Exception::generar();         //ArrayIndex
        //Generador_Exception::generar2(true);        //DivisionByZeroError
        Generador_Exception::generar3() ;
    }catch(Throwable $e){
        echo "".$e->getMessage()."<br>";
        echo $e->__tostring()."<br>";
    }
    echo "El programa termina normalmente!<br>";
    */ 

    //Captura personalizada de Exceptions
    try {
        //Generador_Exception::generar2(true); 
        Generador_Exception::generar3();
    }catch(DivisionByZeroError $e) {
        echo "Error División por cero<br>";
    }catch(Throwable $e){
        echo "Ocurrio un error no esperado!<br>";
    }

    //TODO manejo de reglas de negocio con Exception
    //TODO publicar el segundo trabajo entregable
    

?>