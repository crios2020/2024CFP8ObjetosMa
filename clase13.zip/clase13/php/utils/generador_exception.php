<?php
class Generador_Exception{
    public static function generar(){
        $vector[0]=2;
        $vector[1]= 3;
        echo $vector[6]; 
    }

    public static function generar2(bool $x){
        if($x) echo 10/0;
    }

    public static function generar3(){
        $gestor = fopen("texto.txt", "r");
        echo fread($gestor, 1);
    }

}

?>