<?php
require_once "../entities/persona.php";
require_once "../entities/direccion.php";
class Vendedor extends Persona{
    private $nroLegajo;
    private $sueldo_basico;

    public function __construct(
            string $nombre, 
            int $edad, 
            Direccion $direccion, 
            int $nroLegajo, 
            float $sueldo_basico)
        {
            parent::__construct($nombre, $edad, $direccion); 
            //llama al constructor de clase padre
            $this->nroLegajo=$nroLegajo;
            $this->sueldo_basico=$sueldo_basico;
        }

    public function saludar() : string{
        return "Hola soy un Vendedor!";
    }

    //método sobreescrito
    public function __tostring(): string{
        return  parent::__tostring().", ".  //llama al __tostring de clase padre
                $this->nroLegajo.", ".
                $this->sueldo_basico;
    }
}
?>