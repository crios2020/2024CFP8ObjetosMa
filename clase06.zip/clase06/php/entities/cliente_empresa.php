<?php
require_once "../entities/cuenta.php";
class ClienteEmpresa{
    private $nro;
    private $razon_social;
    private $direccion;
    private $cuentas;

    public function __construct(
                                int $nro, 
                                String $razon_social, 
                                String $direccion
    ){
        $this->nro = $nro;
        $this->razon_social = $razon_social;
        $this->direccion = $direccion;
        $this->cuentas = array();
    }

    public function addCuenta(int $nro, Moneda $moneda){
        $this->cuentas[] = new Cuenta($nro,$moneda);
    }

    public function getCuenta(int $index) :Cuenta{
        return $this->cuentas[$index];
    }

    public function comprar() :string{
        //método Dummy
        return "Comprando un producto!";
    }

    public function __toString() :string{
        return  $this->nro.", ".$this->razon_social.", ".
                $this->direccion.", "."Cantidad de cuentas: ".count($this->cuentas)
                .", ".implode(" - ",$this->cuentas);
    }

     /**
     * Método mágico __get()
     */
    public function __get($property){
        if(property_exists($this,$property)){
            return $this->$property;
        }

    }

    /**
     * Método mágico __set()
     */
    public function __set($property, $value){
        //insert into control_auditoria (user, ip, fecha, hora, accion) values (?,?,?,?,?);
        if(property_exists($this,$property)){
            $this->$property = $value;
        }
    }


}
?>