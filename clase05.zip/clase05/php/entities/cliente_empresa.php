<?php
require_once "../entities/cuenta.php";
class ClienteEmpresa{
    private $nro;
    private $razon_social;
    private $direccion;
    private $cuentas;

    public function __construct(
                                int $nro, 
                                String $razon_social, 
                                String $direccion
    ){
        $this->nro = $nro;
        $this->razon_social = $razon_social;
        $this->direccion = $direccion;
    }

    public function comprar() :string{
        //método Dummy
        return "Comprando un producto!";
    }

    public function __toString() :string{
        return  $this->nro.", ".$this->razon_social.", ".$this->direccion;
    }

     /**
     * Método mágico __get()
     */
    public function __get($property){
        if(property_exists($this,$property)){
            return $this->$property;
        }

    }

    /**
     * Método mágico __set()
     */
    public function __set($property, $value){
        //insert into control_auditoria (user, ip, fecha, hora, accion) values (?,?,?,?,?);
        if(property_exists($this,$property)){
            $this->$property = $value;
        }
    }


}
?>