<?php
require_once "../enums/moneda.php";

class Cuenta{
    private $nro;
    private $moneda;
    private $saldo;

    public function __construct(int $nro, Moneda $moneda){
        $this->nro = $nro;
        $this->moneda = $moneda;
        $this->saldo = 0;
    }

    public function depositar(float $monto){
        //$this->saldo += ($monto+100);
        $this->saldo += $monto;
    }

    public function debitar(float $monto){
        if( $this->saldo >= $monto ){
            $this->saldo -= $monto;
        }else{
            echo "No hay saldo suficiente!<br>";
        }
    }

    public function __tostring() :string{
        return $this->nro.", ".$this->moneda->name.", ".$this->saldo;
    }

    /**
     * Método mágico __get()
     */
    public function __get($property){
        if(property_exists($this,$property)){
            return $this->$property;
        }

    }

    /**
     * Método mágico __set()
     */
    public function __set($property, $value){
        //insert into control_auditoria (user, ip, fecha, hora, accion) values (?,?,?,?,?);
        if(property_exists($this,$property)){
            $this->$property = $value;
        }
    }
}
?>