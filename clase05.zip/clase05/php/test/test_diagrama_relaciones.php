<?php ini_set("display_errors","1"); ?>
<?php
    require_once "../entities/cuenta.php";
    require_once "../entities/cliente_persona.php";
    require_once "../entities/cliente_empresa.php";

    //Relaciones entre clases - Colaboración de clases

    /*
        Test con objetos Mocks (Objetos Simulados)

    */


    echo "-- Test Díagrama Relaciones --<br><br>";
    echo "-- Test Clase Cuenta --<br>";
    echo "-- cuenta1 --<br>";
    $cuenta1=new Cuenta(1,Moneda::ARGS);
    $cuenta1->depositar(500000);
    $cuenta1->depositar(300000);
    $cuenta1->debitar(50000);
    echo $cuenta1."<br>";
    echo "-- End Test Cuenta --<br><br>";

    echo "-- Test Clase ClientePersona --<br>";
    // echo "-- cliente_persona1 --<br>";
    // $cliente_persona1=new ClientePersona(1,"Javier Alvarez",34,2,Moneda::ARGS);
    
    // $cuenta_cliente_persona1=$cliente_persona1->__get("cuenta");
    // $cuenta_cliente_persona1->depositar(1000000);

    // $cliente_persona1->__get("cuenta")->depositar(1000000);

    // echo $cliente_persona1->comprar()."<br>";
    // echo $cliente_persona1."<br>";
     
    echo "-- Ana y Pablo --<br>";
    echo "-- clienteAna --<br>";
    $clienteAna=new ClientePersona(2,"Ana",30,new Cuenta(3,Moneda::ARGS));
    $clienteAna->__get("cuenta")->depositar(1000000);
    $clienteAna->__get("cuenta")->depositar(1000000);
    echo $clienteAna."<br>";

    echo "-- clientePablo --<br>";
    $clientePablo=new ClientePersona(3,"Pablo",30, $clienteAna->__get("cuenta"));
    $clientePablo->__get("cuenta")->debitar(560000);
    echo $clientePablo."<br>";
    echo $clienteAna."<br>";
    echo "-- End Test ClientePersona --<br><br>";

    echo "-- Test Clase ClienteEmpresa --<br>";
    echo "-- clienteEmpresa1 --<br>";
    $clienteEmpresa1=new ClienteEmpresa(1,"Servicios Informaticos","Viel 222");
    //$cuentas=$clienteEmpresa1->__get("cuentas");
    //$cuentas[0]=new Cuenta(10, Moneda::ARGS);     
    echo $clienteEmpresa1."<br>";
    //echo "cuentas: <br>";
    //echo $clienteEmpresa1->__get("cuentas")[0]."<br>";

    echo "-- End Test ClienteEmpresa --<br><br>";
    
?>